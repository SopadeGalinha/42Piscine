#include <unistd.h>
#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	swap;
	int	swap0;

	while(i < (size / 2))
	{
		swap0 = tab[0];
		swap = tab[i];
		tab[i] = tab[size - 1 - i];
		tab [size - 1 -i] = swap;
		i++;
		if ((size > 3) && (size % 2) != 0 && (i + 1 > size / 2))
		{
			tab[0] = swap0;
		}
	}
}

/*int	main()
{
	int	tab[7] = {0, 1, 3, 4, 5, 6, 7}; 
	int	size;

	size = 7;
	ft_rev_int_tab(tab, size);
	printf("%d, %d, %d, %d, %d, %d, %d", tab[0], tab[1], tab[2], tab[3], tab[4], tab[5], tab[6]);
	return (0);
}*/
