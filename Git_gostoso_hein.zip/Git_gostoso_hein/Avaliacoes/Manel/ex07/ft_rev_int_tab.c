/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mapiment <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 11:34:42 by mapiment          #+#    #+#             */
/*   Updated: 2023/03/18 11:16:12 by mapiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	tmp;

	i = 0;
	tmp = 0;
	while (i - size < 0)
	{
		tmp = tab[i];
		tab[i] = tab[size - 1];
		tab[size - 1] = tmp;
		i++;
		size--;
	}
}
/*
#include <stdio.h>
int main(void){
    int vec[20]= {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
    12, 13, 14, 15, 16, 17, 18, 19, 20};
    int i=0, size=sizeof(vec) / sizeof(int);

    ft_rev_int_tab(vec,size);
    while (i!=size)
    {
        printf("%d ", vec[i]);
        i++;
    }
    
}
*/