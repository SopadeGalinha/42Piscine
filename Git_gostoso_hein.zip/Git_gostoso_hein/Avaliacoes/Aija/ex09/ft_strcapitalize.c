/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arepsa <arepsa@student.42porto.com>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 12:58:48 by arepsa            #+#    #+#             */
/*   Updated: 2023/03/20 11:56:37 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (*str != '\0')
	{
		if (i == 0 && *str >= 'a' && *str <= 'z')
		{
			*str = *str - 32;
			i++;
		}
		else if (i > 0 && *str >= 'A' && *str <= 'Z')
			*str = *str + 32;
		else if ((*str < 'a' || *str > 'z')
			&& (*str < 'A' || *str > 'Z')
			&& (*str < '0' || *str > '9'))
			i = 0;
		else
			i++;
		str++;
	}
	return (str);
}

int main()
{
	char c[] = "Viar fd iojfd-fd df. df,fd.u";
	printf("%s", ft_strcapitalize(c));
	return (0);
}
