/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tibarbos <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/18 13:41:14 by tibarbos          #+#    #+#             */
/*   Updated: 2023/03/20 19:12:22 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0')
	{
		if (i < size)
		{
			dest[i] = src[i];
		}
	i++;
	}
	dest[size] = '\0';
	return (i);
}

int	main(void)
{
	char	dest[] = "hello world";
	char	src[] = "goo";

	ft_strlcpy(dest, src, 6);
	printf("%s", dest);
	printf("\n");
	printf("%d", ft_strlcpy(dest, src, 6));
}

