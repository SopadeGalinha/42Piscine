/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bapereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 14:54:07 by bapereir          #+#    #+#             */
/*   Updated: 2023/03/24 11:10:44 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0')
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] >= 32 && str[i] <= 126)
		{
			return (1);
		}
		i++;
	}
	return (0);
}

int main()
{
	printf("%d", ft_str_is_printable("df afP[-+dfs"));
	printf("%d", ft_str_is_printable("\nsf"));
	printf("%d", ft_str_is_printable(""));
}

/*
 *
 *int	main(void)
{
	printf("ABC:%d\n", ft_str_is_printable("\vi \rA\tB\nC"));
	printf("©:%d\n", ft_str_is_printable("©\n"));
}*/
