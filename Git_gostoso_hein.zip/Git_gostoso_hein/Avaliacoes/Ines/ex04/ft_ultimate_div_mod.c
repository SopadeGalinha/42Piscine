/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 10:35:42 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/16 11:19:03 by inemarti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;

	if (b)
	{
		div = (*a) / (*b);
		mod = (*a) % (*b);
		*a = div;
		*b = mod;
	}
}

/*#include <stdio.h>

int	main()
{
	int c = 13;
	int d = 4;

	printf("%d /", c);
	printf(" %d\n",d);

	ft_ultimate_div_mod(&c, &d);

	printf("div (*a) = %d\n", c);
	printf("mod (*b) = %d\n", d);
}*/
