/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfacanha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/19 21:06:12 by cfacanha          #+#    #+#             */
/*   Updated: 2023/03/19 21:06:18 by cfacanha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*#include <stdio.h>
*/
int	ft_strlen(char *str)
{	
	int	i;

	i = 0;
	while (*str++)
		i++;
	return (i);
}
/*
int	main()
{
	printf("%d", ft_strlen("esternocleidomastoideo"));
	return (0);
}*/
