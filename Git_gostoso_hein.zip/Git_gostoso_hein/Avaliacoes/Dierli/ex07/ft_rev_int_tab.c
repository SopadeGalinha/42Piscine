/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dierdos- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/15 15:47:50 by dierdos-          #+#    #+#             */
/*   Updated: 2023/03/15 16:17:13 by dierdos-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void	ft_rev_int_lab(int *tab, int size)
{
	int	i;
	int	t;

	i = 0;
	while (i < (size / 2))
	{
		t = tab[i];
		tab[i] = tab [size - 1 - i];
		tab [size - 1 - i] = t;
		i++;
	}
}
