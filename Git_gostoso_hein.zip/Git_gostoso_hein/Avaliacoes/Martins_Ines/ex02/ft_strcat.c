/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/22 09:53:10 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/23 13:48:42 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	a;
	int	len;

	a = 0;
	len = 0;
	while (dest[len] != '\0')
	{
		len++;
	}
	while (src[a] != '\0')
	{
		dest[len + a] = src[a];
		a++;
	}
	dest[len + a] = '\0';
	return (dest);
}

#include <stdio.h>

int	main(void)
{
	char	str1[30] = "Hello";
	char	str2[] = " world!";

	ft_strcat(str1, str2);
	printf("%s", str1);
	return (0);
}
