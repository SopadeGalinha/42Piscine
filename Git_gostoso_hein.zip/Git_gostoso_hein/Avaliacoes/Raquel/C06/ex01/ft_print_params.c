/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rvarela- <rvarela-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 12:02:43 by rvarela-          #+#    #+#             */
/*   Updated: 2023/03/21 18:18:00 by rvarela-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

void	ft_putstr(char *str)
{
	unsigned int	a;

	a = 0;
	while (str[a] != '\0')
	{
		ft_putchar(str[a]);
		a++;
	}
}

int	main(int ac, char **av)
{
	int	i;

	i = 1;
	while (ac > 0 && i < ac)
	{
		ft_putstr(av[i]);
		write (1, "\n", 1);
		i++;
	}
	return (0);
}
