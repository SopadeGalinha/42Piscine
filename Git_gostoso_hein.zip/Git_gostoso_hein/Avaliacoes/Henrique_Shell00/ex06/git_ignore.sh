#!/bin/sh

git ls-files --exclude-standard --others --ignored

