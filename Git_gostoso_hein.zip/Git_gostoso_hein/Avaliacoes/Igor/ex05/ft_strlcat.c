/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yfreitas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/25 08:40:54 by yfreitas          #+#    #+#             */
/*   Updated: 2023/03/25 09:05:20 by yfreitas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <string.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	a;

	i = 0;
	j = 0;
	a = 0;
	while (dest[i])
		i++;
	while (src[j])
		j++;
	if (size <= i)
		return (j + size);
	while (src[a] && ((i + a) < (size - 1)))
	{
		dest[i + a] = src[a];
		a++;
	}
	dest[i + a] = '\0';
	return (j + i);
}

int main (void)
{
	char dest[] = "oi3456";
	char src[] = "Hello";
	printf("%i \n", ft_strlcat(dest, src, 5));
	printf("%s \n", dest);
}
