/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 09:51:36 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/22 12:23:07 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}
/*
int	main()
{
	char src[] = "Hello World";
	char dest[] = "Clara Mente12";
	char dest1[] = "Clara Mente13";

	printf("%s\n", ft_strncpy(dest, src, 5));
	printf("%s\n", strncpy(dest1, src, 5));
	printf("%s\n", ft_strncpy(dest, src, 7));
	printf("%s\n", strncpy(dest1, src, 7));
	printf("%s\n", ft_strncpy(dest, src, 11));
	printf("%s", strncpy(dest1, src, 11));
}*/
