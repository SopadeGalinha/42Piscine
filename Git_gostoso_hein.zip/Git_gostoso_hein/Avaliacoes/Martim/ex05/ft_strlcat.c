/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mcarneir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/19 20:46:06 by mcarneir          #+#    #+#             */
/*   Updated: 2023/03/20 18:54:21 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	dl;
	unsigned int	sl;
	unsigned int	i;

	dl = 0;
	sl = 0;
	i = 0;
	while (dest[dl] != '\0' && dl < size)
	{
		dl++;
	}
	while (src[sl] != '\0')
	{
		sl++;
	}
	if (dl == size)
		return (size + sl);
	while (src[i] != '\0' && i < size -1)
	{
		dest[dl + i] = src[i];
		i++;
	}
	dest[dl + i] = '\0';
	return (dl + sl);
}


/*int	main(void)
{
	char	str1[] = "Hello";
	char	str2[] = " world";
	unsigned int	size;
	unsigned int	length;

	size = 6;
	length = ft_strlcat(str1, str2, size);
	printf("Result: %s\n", str1);
	printf("Length of the resulting string: %u", length);

}*/

int main (void)
{
	char src[] = "temos de nos manter juntos...";
	char dest[] = "Nos, os estranhos, ";
	printf("%i \n", ft_strlcat(dest, src, 49));
	printf("%s \n", dest);
}
