/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: avasques <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/13 19:36:25 by avasques          #+#    #+#             */
/*   Updated: 2023/03/20 09:39:06 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	combo(char c)
{
	write(1, &c, 1);
}

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = -1;
	while (a++ < 98)
	{
		b = a;
		while (b++ < 99)
		{
			combo (48 + (a / 10));
			combo (48 + (a % 10));
			write (1, " ", 1);
			combo (48 + (b / 10));
			combo (48 + (b % 10));
			if (a != 98)
			{
				write(1, ", ", 2);
			}
		}
	}
}

int main()
{
	ft_print_comb2();
}
