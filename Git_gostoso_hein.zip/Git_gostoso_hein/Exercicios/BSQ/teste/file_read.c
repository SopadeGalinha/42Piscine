#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
//void    ft_file_read(char *filepath, t_dict **begin)
int main()
{
    int fd;
    char buf[1046];
    int size;

    //char *buffer = malloc(sizeof(char) * size);
    int file;
    char *dictpath;
    dictpath = "file.txt";
    fd = open(dictpath, O_RDONLY);
    while (read(fd, &buf, 1))
    {
        buff_size++;
            printf("Buf: %s \n", buf);
    }

    (read(fd, &buf, buff_size));      
    file = open(dictpath, O_RDONLY);
    

   // size = read(file, buf, 5000);
    printf("Buf: %s \n", buf);
    close (file);
}