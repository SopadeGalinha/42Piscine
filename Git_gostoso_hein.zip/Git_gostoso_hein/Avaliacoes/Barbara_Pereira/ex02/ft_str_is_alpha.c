/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bapereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/22 19:07:32 by bapereir          #+#    #+#             */
/*   Updated: 2023/03/24 11:04:32 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] < 'A' || str[i] > 'Z')
		{
			if (str[i] < 'a' || str[i] > 'z')
			{
				return (0);
			}
		}
		i++;
	}
	return (1);
}

int	main(void)
{
	char	*str1;
	char	*str2;
	char	*str3;
	char *str4;
	char *str5;
	char *str6;
	char *str7;
	char *str8;
	char *str9;
	char *str10;

	str1 = calloc(10, sizeof(char));
	str2 = calloc(10, sizeof(char));
	str3 = calloc(10, sizeof(char));
	str4 = calloc(10, sizeof(char));
	str5 = calloc(10, sizeof(char));
	str6 = calloc(10, sizeof(char));
	str7 = calloc(10, sizeof(char));
	str8 = calloc(10, sizeof(char));
	str1 = "AbCdeFgHi";
	str2 = "12";
	str3 = "2bCdze2gHi";
	str4 = "abCde2gH2";
	str5 = "dasdsadas";
	str6 = ".kl..[";
	str7 = "az84545az";
	str8 = "AZ45455az";
	str9 = "]";
	str10 = "AZ";
	
	printf("--Retorna 1 caso a string passada tenha caracteres alfabeticos--\n");
	//printf 0 se tiver outro tipo de caracteres--");
	printf("str1: %s, is_aplha: %d\n", str1, ft_str_is_alpha(str1));
	printf("str2: %s, is_aplha: %d\n", str2, ft_str_is_alpha(str2));
	printf("str3: %s, is_aplha: %d\n", str3, ft_str_is_alpha(str3));
	printf("str4: %s, is_aplha: %d\n", str4, ft_str_is_alpha(str4));
	printf("str5: %s, is_aplha: %d\n", str5, ft_str_is_alpha(str5));
	printf("str6: %s, is_aplha: %d\n", str6, ft_str_is_alpha(str6));
	printf("str5: %s, is_aplha: %d\n", str7, ft_str_is_alpha(str7));
	printf("str6: %s, is_aplha: %d\n", str8, ft_str_is_alpha(str8));
	printf("str5: %s, is_aplha: %d\n", str9, ft_str_is_alpha(str9));
	printf("str6: %s, is_aplha: %d\n", str10, ft_str_is_alpha(str10));
	return (0);
}
