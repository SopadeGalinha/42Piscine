/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carolive <carolive@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 15:09:17 by carolive          #+#    #+#             */
/*   Updated: 2023/03/21 17:02:01 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int	i;
	int	number;

	i = 0;
	number = n;
	while (src[i] != '\0' && i < number)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

#include <stdio.h>

int     main(void)
{
    char    *src;
    char    dest[5];

    src = "carlos";
    printf("antes destino: %s\n", dest);
    printf("antes source: %s\n", src);
    ft_strncpy(dest, src, 2);
    printf("depois destino: %s\n", dest);
    printf("depois source: %s\n", src);

}
