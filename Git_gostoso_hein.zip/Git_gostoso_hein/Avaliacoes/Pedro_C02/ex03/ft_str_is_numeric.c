/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pde-frei <pde-frei@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/19 20:52:21 by pde-frei          #+#    #+#             */
/*   Updated: 2023/03/20 20:52:13 by pde-frei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9' ))
			return (0);
		i++;
	}
	return (1);
}
/*
int main()
{
        char *str_str;

        str_str = "1231241";
        printf("%d\n",ft_str_is_numeric(str_str));
}
*/
