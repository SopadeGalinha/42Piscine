/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedmonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 11:57:22 by pedmonte          #+#    #+#             */
/*   Updated: 2023/03/19 15:10:01 by pedmonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	int	x;

	i = 0;
	while ((s1[i] == s2[i]) && (s1[i] != '\0' || s2[i] != '\0'))
	{
		i++;
	}
	x = s1[i] - s2[i];
	return (x);
}
/*
int main()
{
	char	*s1= "Escola42";
	char	*s2= "";
	printf("%d", ft_strcmp(s1, s2));
	printf("\n%d", strcmp(s1, s2));
}*/
