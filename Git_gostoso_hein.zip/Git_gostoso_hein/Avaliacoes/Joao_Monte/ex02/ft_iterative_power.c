/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joamonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/21 14:24:58 by joamonte          #+#    #+#             */
/*   Updated: 2023/03/21 14:45:12 by joamonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	n;

	n = nb;
	i = 1;
	if (power == 0)
		return (1);
	if (power > 0)
	{
		while (i < power)
		{
			nb *= n;
			i++;
		}
		return (nb);
	}
	else
		return (0);
}
/*
int	main(void)
{
	printf("%d", ft_iterative_power(-3, 3));
}
*/
