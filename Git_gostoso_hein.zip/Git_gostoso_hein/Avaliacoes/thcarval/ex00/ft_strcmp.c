/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thcarval <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 14:54:54 by thcarval          #+#    #+#             */
/*   Updated: 2023/03/27 22:36:16 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while ((s1[i] == s2[i]) && ((s1[i] != '\0') || (s2[i] != '\0')))
	{
		i++;
	}
	return (s1[i] - s2[i]);
}

int	main(void)
{
	char	s1;
	char	s2;

	s1 [] = "Hello";
	s2 [] = "Pisciners";
	ft_strcmp(s1,s2);
	printf ("%d", ft_strcmp(s1,s2));
}

