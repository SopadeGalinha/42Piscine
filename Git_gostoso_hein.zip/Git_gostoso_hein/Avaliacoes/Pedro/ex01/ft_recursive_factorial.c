/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedro-ma <pedro-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/19 14:37:13 by pedro-ma          #+#    #+#             */
/*   Updated: 2023/03/19 14:51:27 by pedro-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	unsigned int	a;

	if (nb < 0)
		return (0);
	else if (nb > 0)
	{
		a = ft_recursive_factorial(nb -1);
		a *= nb;
		nb--;
	}
	else
		return (1);
	return (a);
}

/*#include <stdio.h>
int	ft_recursive_factorial(int nb);
int	main(void)
{
	int nb;
	int res;

	nb = -5;
	while (nb <= 10)
	{
		res = ft_recursive_factorial(nb);
		printf("> n = %d, n! = %d\n", nb, res);
		nb++;
	}
	return (0);
}*/