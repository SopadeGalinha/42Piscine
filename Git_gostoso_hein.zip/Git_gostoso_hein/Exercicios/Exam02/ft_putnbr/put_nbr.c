/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_nbr.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rboia-pe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/24 19:54:38 by rboia-pe          #+#    #+#             */
/*   Updated: 2023/03/24 20:20:22 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <limits.h>
#include <stdio.h>

void	ft_putchar(char c)
{
	c += '0';
	write (1, &c, 1);
}

void	ft_putnbr(int nb)
{
	int	div;
	int	mod;
	
	if (nb == -2147483648)
	{
		write (1, "-2", 2);
		ft_putnbr(147483648);
	}
	else if (nb < 0)
	{
		write (1, "-", 1);
		nb *= -1;
		ft_putnbr(nb);
	}
	else if (nb > 9)
	{
		div = (nb / 10);
		ft_putnbr(div);
		mod = (nb % 10);
		ft_putnbr(mod);
	}
	else
		ft_putchar(nb);
}

int main()
{
	printf("Int Max: %d \n", INT_MAX);
	printf("Int Mn: %d \n", INT_MIN);
	int i = -2147483648;
	ft_putnbr(i);
}
