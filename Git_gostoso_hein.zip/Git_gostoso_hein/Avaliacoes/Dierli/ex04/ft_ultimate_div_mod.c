/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dierdos- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/15 11:00:22 by dierdos-          #+#    #+#             */
/*   Updated: 2023/03/15 17:51:27 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *a / *b;
	*b = temp % *b;
}
int	main(void)
{
	int *a;
	int *b;
	int j;
	int i;

	j = 10;
	i = 2;
	a = calloc(1, sizeof(int));
	b = calloc(1, sizeof(int));
	
	a = &j;
	b = &i;
	
	ft_ultimate_div_mod(a, b);
	printf("a: %d, b: %d\n", *a, *b);


	return (0);
}
