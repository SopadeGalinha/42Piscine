/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfacanha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 17:40:33 by cfacanha          #+#    #+#             */
/*   Updated: 2023/03/16 17:42:20 by cfacanha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*a funcao divide os dois parametros a e b e armazena o resultado no inteiro apontado por div.
ela tambem armazena o resto da divisao de a e b no ponteiro apontado por mod.*/
void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
/*
int    main(void)
{
    int x;
    int y;
  
    ft_div_mod(9, 5, &x, &y);
    printf("%d \n", x);
    printf("%d", y);
}*/
