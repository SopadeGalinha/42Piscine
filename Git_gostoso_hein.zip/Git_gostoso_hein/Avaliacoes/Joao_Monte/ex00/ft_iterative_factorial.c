/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joamonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/21 09:31:25 by joamonte          #+#    #+#             */
/*   Updated: 2023/03/22 10:37:28 by joamonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_iterative_factorial(int nb)
{
	unsigned int	f;

	f = 1;
	while (nb > 0)
	{
		f = f * nb;
		nb--;
	}
	if (nb < 0)
	{
		return (0);
	}
	return (f);
}
/*
int	main(void)
{
	printf("%d", ft_iterative_factorial(4));
	return(0);
}
*/
