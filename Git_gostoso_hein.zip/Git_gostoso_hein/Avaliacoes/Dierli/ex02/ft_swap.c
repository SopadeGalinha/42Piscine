/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dierdos- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/15 10:03:57 by dierdos-          #+#    #+#             */
/*   Updated: 2023/03/15 17:49:17 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

int main(void)
{
	int n1 = 10;
	int n2 = 20;
	int *a = &n1;
	int *b = &n2;
	
	printf("antes n1: %d, n2: %d", n1, n2);
	ft_swap(a, b);
	printf("depois n1: %d, n2: %d", *a, *b);
	return(0);
}
