/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 14:31:08 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/16 16:12:00 by inemarti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	index;
	int	a;

	index = 0;
	while (index < size)
	{
		a = tab[index];
		tab[index] = tab[size -1];
		tab[size -1] = a;
		index++;
		size--;
	}
}

/*#include <stdio.h>

int	main(void)
{
	int	index;
	int	x[] = {20,21,22,23,24,25,26,27,28,29};
	int	size;

	index = 0;
	size = 10;
	ft_rev_int_tab(x, size);
	while (index < size)
	{
		printf("After reversing -> %d \n", x[index]);
		index++;
	}
}*/
