/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/14 18:16:00 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/16 09:55:22 by inemarti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	swap;

	swap = *a;
	*a = *b;
	*b = swap;
}

/*#include <stdio.h>

int	main()
{
	int a = 1;
	int b = 2;

	printf("Before-> %d\n", a);
	ft_swap(&a, &b);
	printf("After-> %d", b);
}*/
