/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedro-ma <pedro-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 09:02:22 by pedro-ma          #+#    #+#             */
/*   Updated: 2023/03/20 09:14:11 by pedro-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	unsigned int	a;

	if (power == 0)
		return (1);
	else if (power < 0)
		return (0);
	else
	{
		a = ft_recursive_power(nb, (power - 1));
		a *= nb;
		power--;
	}
	return (a);
}

/*#include <stdio.h>
int main(void)
{
	printf("%i", ft_recursive_power(-5, 6));
}*/
