/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tibarbos <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 11:38:41 by tibarbos          #+#    #+#             */
/*   Updated: 2023/03/20 19:10:29 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

void	tudo_pequenas(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] += 32;
		}
	i++;
	}
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	tudo_pequenas(str);
	while (str[i] != '\0')
	{
		if ((!(str[i] >= 'a' && str[i] <= 'z')
				&& (!(str[i] >= 'A' && str[i] <= 'Z')))
			&& str[i + 1] >= 'a' && str[i + 1] <= 'z')
		{
			if (!(str[i] >= '0' && str[i] <= '9'))
			{
				str[i + 1] -= 32;
			}
		}
	i++;
	}
	if (str[0] >= 'a' && str[0] <= 'z')
	{
		str[0] -= 32;
	}
	return (str);
}

int	main()
{
	char	str[] = "ola, tudo bem? 42palavras quarenta-e-duas; cinquenta+e+um";
	
	printf("%s", ft_strcapitalize(str));
}

