/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedro-ma <pedro-ma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 09:52:44 by pedro-ma          #+#    #+#             */
/*   Updated: 2023/03/22 11:01:33 by pedro-ma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int	a;
	int	b;

	b = nb;
	if (b <= 0)
		return (0);
	if (b == 1)
		return (1);
	if (b > 1)
	{
		a = 2;
		while (a * a <= b)
		{
			if (a * a == b)
			{
				return (a);
			}
			a++;
		}
	}
	return (0);
}

/*#include <stdio.h>

int		main(void)
{
	printf("resultado %d\n", ft_sqrt(125));
	return (0);
}*/