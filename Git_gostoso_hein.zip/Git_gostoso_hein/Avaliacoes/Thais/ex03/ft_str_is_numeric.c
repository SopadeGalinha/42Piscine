/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 11:11:28 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/20 11:20:29 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_numeric(char *str)
{
	if (!*str)
	{
		return (1);
	}
	while (*str)
	{
		if (*str >= '0' && *str <= '9')
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int main(void)
{
    char str1[] = "1340987768349";
    char str2[] = "H3ll0 Wor1d!";
    char str3[] = "";

    printf("first %s\nsecond %s\nthird %s\n", str1, str2, str3);
    printf("%d\n%d\n%d\n", ft_str_is_numeric(str1), ft_str_is_numeric(str2), 
    		ft_str_is_numeric(str3));
}*/
