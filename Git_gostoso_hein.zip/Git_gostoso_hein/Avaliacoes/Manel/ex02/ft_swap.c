/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mapiment <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/15 14:25:16 by mapiment          #+#    #+#             */
/*   Updated: 2023/03/17 09:11:35 by mapiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}
/*
#include <stdio.h>
int main(void){
    int a,b;
    a=1;
    b=2;
    int *pa=&a,*pb=&b;
    ft_swap(pa,pb);
    printf("%d\n",*pa);
    printf("%d\n",*pb);
}
*/
