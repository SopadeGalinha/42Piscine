/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfacanha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/19 18:05:03 by cfacanha          #+#    #+#             */
/*   Updated: 2023/03/19 18:05:20 by cfacanha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*
#include <unistd.h>
*/
void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;
	
	div = *a / *b;
	mod = *a% *b;
	*a = div;
	*b = mod;
}
/*
#include <stdio.h>
#include <stdlib.h>

int	main(void)
{
	int *a;
	int *b;
	a = calloc(1, sizeof(int));
	b = calloc(1, sizeof(int));
	*a = 42;
	*b = 10;
	printf("*a: %d, *b: %d\n", *a, *b);
	ft_ultimate_div_mod(a, b);
	printf("*a: %d, *b: %d\n", *a, *b);
	return (0);
}*/
