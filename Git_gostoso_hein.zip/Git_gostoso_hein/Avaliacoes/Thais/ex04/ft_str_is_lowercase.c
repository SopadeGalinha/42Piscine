/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 11:21:04 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/20 11:47:54 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_lowercase(char *str)
{
	if (!*str)
	{
		return (1);
	}
	while (*str)
	{
		if (*str >= 'a' && *str <= 'z')
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int main (void)
{
	char str1[] = "abcdierbfjkbz";
	char str2[] = "SJKDVHONkdsjhzc";
	char str3[] = "Hello World";
	char str4[] = "";

	printf("%d\n%d\n%d\n%d\n", ft_str_is_lowercase(str1), 
		ft_str_is_lowercase(str2), ft_str_is_lowercase(str3),
		ft_str_is_lowercase(str4));
}*/
