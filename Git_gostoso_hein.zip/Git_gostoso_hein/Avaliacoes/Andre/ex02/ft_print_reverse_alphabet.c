/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: avasques <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/10 08:44:52 by avasques          #+#    #+#             */
/*   Updated: 2023/03/20 09:34:01 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_reserve_alphabet(void)
{
	char	c;

	while (c >= 'a')
	{
		write (1, &c, 1);
		c--;
	}
}

int	main()
{
	ft_print_reserve_alphabet();
}
