/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dfreitas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/29 19:55:06 by dfreitas          #+#    #+#             */
/*   Updated: 2023/03/30 08:23:59 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_sqrt(int nb)
{
	int		i;

	i = 0;
	if (nb <= 0)
		return (0);
	while ((i * i < nb) && (i <= 46340))
		i++;
	if (i * i == nb)
		return (i);
	else
		return (0);
}

int	main()
{
	printf("%d\n",ft_sqrt(64));
}
