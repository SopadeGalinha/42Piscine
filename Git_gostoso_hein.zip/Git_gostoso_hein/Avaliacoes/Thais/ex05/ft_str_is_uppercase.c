/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 11:36:16 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/20 11:47:24 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_uppercase(char *str)
{
	if (!*str)
	{
		return (1);
	}
	while (*str)
	{
		if (*str >= 'A' && *str <= 'Z')
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int main (void)
{
	char str1[] = "SLKDFHWKDHJWLK";
	char str2[] = "SJKDVHONkdsjhc";
	char str3[] = "Hello World";
	char str4[] = "";

	printf("%d\n%d\n%d\n%d\n", ft_str_is_uppercase(str1), 
		ft_str_is_uppercase(str2), ft_str_is_uppercase(str3), 
		ft_str_is_uppercase(str4));
}*/
