/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glima-da <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 12:46:04 by glima-da          #+#    #+#             */
/*   Updated: 2023/03/23 12:46:05 by glima-da         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	n;
	int	tab2[size];

	n = 0;
	size--;
	while (size >= 0)
	{
		tab2[n] = tab[size];
		n++;
		size--;
	}
	n--;
	size++;
	while (size <= n)
	{
		tab[size] = tab2[size];
		size++;
	}
}
