/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arepsa <arepsa@student.42porto.com>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 12:35:06 by arepsa            #+#    #+#             */
/*   Updated: 2023/03/20 11:54:24 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

char	*ft_strlowcase(char *str)
{
	//printf("%s\n", "gf");
	while (*str != '\0')
	{
	printf("%s\n", str);
		if (*str >= 65 && *str <= 90)
		{
		//	printf("%s\n", "gf");
			*str = *str + 32;
		}
	str++;
	}
	return (str);
}

int main()
{
	char c[] = "rifn";
	printf("%s", ft_strlowcase(c));
	return(0);
}
