/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mcarneir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 18:02:04 by mcarneir          #+#    #+#             */
/*   Updated: 2023/03/20 18:38:36 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

char	*ft_strcat(char *dest, char *src)
{
	int	a;
	int	len;

	a = 0;
	len = 0;
	while (dest[len] != '\0')
	{
		len++;
	}
	while (src[a] != '\0')
	{
		dest[len + a] = src[a];
		a++;
	}
	dest[len + a] = '\0';
	return (dest);
}

int 	main(void) 
{
    char str1[50] = "Hello";
    char str2[] = " world!";
    ft_strcat(str1, str2);
    printf("%s", str1); // output: Hello world!
    return 0;
}

