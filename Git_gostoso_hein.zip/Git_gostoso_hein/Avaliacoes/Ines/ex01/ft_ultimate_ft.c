/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/14 18:07:45 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/15 18:14:38 by inemarti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

/*#include <stdio.h>

int	main()
{
	int	n;
	int	*pn1, **pn2, ***pn3, ****pn4, *****pn5, ******pn6, *******pn7, ********pn8, *********pn9;

	pn9 = &pn8;
	pn8 = &pn7;
	pn7 = &pn6;
	pn6 = &pn5;
	pn5 = &pn4;
	pn4 = &pn3;
	pn3 = &pn2;
	pn2 = &pn1;
	pn1 = &n;
	
	n = 51;
	printf("Before-> %d\n", n);
	ft_ultimate_ft(pn9);
	printf("After-> %d\n", n);
}*/
