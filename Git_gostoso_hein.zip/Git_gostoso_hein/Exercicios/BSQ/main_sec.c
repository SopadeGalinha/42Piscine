/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_sec.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By:  rboia-pe@student.42porto.com  <rboia-p    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/28 04:40:17 by  rboia-pe@s       #+#    #+#             */
/*   Updated: 2023/03/28 06:55:54 by  rboia-pe@s      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int main(int argc, char **argv)
{
	int	x;
	int	y;
	int	density;
	int	i;
	int	j;
	int fd;	

	char	**grid;
	char	buf;
	
	if (!(argc % 2 == 0) || argc == 0)
		return (write(1, "Error\n", 6));
	i = 0;
	j = 0;
    x = ft_atoi(&*argv[1]);
    y = x;
    density = ft_atoi(&*argv[2]);
// Abrir o arquivo
fd = open(argv[argc - 1], O_RDONLY);
if (fd < 0) {
    perror("open");
    exit(1);
}

// Allocate memory for grid
grid = (char **) malloc(y * sizeof(char *));
for (int i = 0; i < y; i++) {
    grid[i] = (char *) malloc(x * sizeof(char));
}

// Ler o arquivo caractere por caractere e preencher o grid
i = 0;
j = 0;
while (read(fd, &buf, 1) > 0) {
    if (buf == '\n') {
        i++;
        j = 0;
    } else {
        grid[i][j] = buf;
        j++;
    }
}

// Fechar o arquivo
close(fd);


	printf("%s\n", grid[5]);
	_exit(1);
	ft_print_grid(grid, y, x);
	ft_find_largest_square(grid, x, y);
    close(fd);
    return (0);
}