/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bapereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 14:41:25 by bapereir          #+#    #+#             */
/*   Updated: 2023/03/24 11:08:31 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] < 'A' || str[i] > 'Z')
		{
			return (0);
		}
			i++;
	}
	return (1);
}

int	main(void)
{
	printf("ABC:%d\n", ft_str_is_uppercase("ABC"));
	printf("abc:%d\n", ft_str_is_uppercase("abc"));
	printf("AbC:%d\n", ft_str_is_uppercase("AbC"));
	printf(":%d\n", ft_str_is_uppercase(""));
}
