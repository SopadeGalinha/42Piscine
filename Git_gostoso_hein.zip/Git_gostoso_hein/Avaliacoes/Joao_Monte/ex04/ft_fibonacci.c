/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joamonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/21 19:07:25 by joamonte          #+#    #+#             */
/*   Updated: 2023/03/22 09:21:23 by joamonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_fibonacci(int index)
{
	int	f;

	if (index >= 2)
		f = ft_fibonacci(index - 2) + ft_fibonacci(index - 1);
	if (index < 0)
		return (-1);
	if (index < 2)
		return (index);
	return (f);
}
/*
int	main(void)
{
	printf("%d", ft_fibonacci(5));
}
*/
