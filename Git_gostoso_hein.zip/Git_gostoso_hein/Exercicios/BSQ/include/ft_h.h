#ifndef FT_H_H
# define FT_H_H
​
# define __BUFF 3

#include <stdlib.h>
#include <time.h>
#include <unistd.h>



int	ft_atoi(char *str);
void	max_coords(char **grid, int *pos, int *max_size, int *max_x, int *max_y);
void	calculate_size(char **grid, int rows, int cols, int **size);
int	ft_min_int(int a, int b);
void	max_square_coords_helper(int *pos,int **size, int *max_size, int *max_x, int *max_y);
void	ft_putnbr(int n);
void	mark_square(char **grid, int *pos, int max_x, int max_y, int max_size);
void	ft_print_grid(char **grid, int rows, int cols);
void	ft_find_largest_square(char **grid, int x, int y);




#endif
