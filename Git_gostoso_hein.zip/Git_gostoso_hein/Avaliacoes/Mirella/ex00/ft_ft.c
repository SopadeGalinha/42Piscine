/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfacanha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 16:44:57 by cfacanha          #+#    #+#             */
/*   Updated: 2023/03/16 16:45:18 by cfacanha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
/*escreva uma funcao que receba um ponteiro para inteiro como parametro e colque no inteiro o valor '42'.*/
void	ft_ft(int *nbr)
{
	*nbr = 42;
}
/*
int	main()
{
	int	*nr;
	int	number;
	
	nr = &number;
	ft_ft(nr);
	printf("%d", number);
}*/
