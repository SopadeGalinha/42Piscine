/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mapiment <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 09:53:24 by mapiment          #+#    #+#             */
/*   Updated: 2023/03/17 09:13:11 by mapiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
/*
#include <stdio.h>
int main(void){
    int a=42, b=24, c=0, d=0;
    ft_div_mod(a,b,&c,&d);
    printf("%d\n",c);
    printf("%d\n",d);
}
*/
