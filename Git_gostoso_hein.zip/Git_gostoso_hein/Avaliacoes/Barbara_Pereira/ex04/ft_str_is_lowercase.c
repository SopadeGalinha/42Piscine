/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bapereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 13:00:33 by bapereir          #+#    #+#             */
/*   Updated: 2023/03/24 11:06:29 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] < 'a' || str[i] > 'z')
		{
			return (1);
		}
		i++;
	}
	return (0);
}

int	main(void)
{
	printf("abc:%d\n", ft_str_is_lowercase("abc"));
	printf("AbC:%d\n", ft_str_is_lowercase("AbC"));
	printf(":%d\n", ft_str_is_lowercase(" "));
	return (0);
}
