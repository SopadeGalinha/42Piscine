/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pemontei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 23:48:43 by pemontei          #+#    #+#             */
/*   Updated: 2023/03/21 00:20:08 by pemontei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

unsigned int	ft_strlen(char *str)
{
	unsigned int	n;

	n = 0;
	while (str[n] != '\0')
		n++;
	return (n);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	int				h;

	i = 0;
	h = 0;
	if (size <= ft_strlen(dest))
		return (size + ft_strlen(src));
	i = ft_strlen(dest);
	while (src[h] != '\0' && i + 1 < size)
	{
		dest[i] = src[h];
		i++;
		h++;
	}
	dest[i] = '\0';
	return (ft_strlen(dest) + ft_strlen(&src[h]));
}
/*int	main(void)
{
	char	src[20] = "PedroLuisGomes";
	char	dest[] = "Carta 554 ";
    printf("%i \n", ft_strlcat(dest, src, 15));
    printf("%s \n", dest);
}*/
