/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/21 10:23:23 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/21 10:24:49 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	next;

	i = 0;
	next = 1;
	while (str[i] != '\0')
	{
		if (next == 1 && str[i] >= 97 && str[i] <= 122)
		{
			str[i] -= 32;
		}
		else if (next == 0 && str[i] >= 65 && str[i] <= 90)
		{
			str[i] += 32;
		}
		if ((str[i] >= 32 && str[i] <= 47)
			|| (str[i] >= 58 && str[i] <= 64)
			|| (str[i] >= 123 && str[i] <= 126)
			|| (str[i] >= 91 && str[i] <= 96))
			next = 1;
		else
			next = 0;
		i++;
	}
	return (str);
}
/*
int	main()
{
	char str[] = "ola, tudo bem? 42palavras quarenta-e-duas;";
	char str1[] = "diujndfvon,odficj,dc dsfovij?kl43lo+dd-sdk%cdj*d";
	printf("%s", ft_strcapitalize(str));
	printf("\n%s", ft_strcapitalize(str1));
}*/
