/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pemontei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 23:02:38 by pemontei          #+#    #+#             */
/*   Updated: 2023/03/20 23:02:40 by pemontei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char				*sdest;
	unsigned int		i;
	unsigned int		h;

	i = 0;
	h = 0;
	sdest = dest;
	while (dest[i] != '\0')
	{
		i++;
	}
	while (src[h] != '\0' && h < nb)
	{
		dest[i + h] = src[h];
		h++;
	}
	dest[i + h] = '\0';
	return (sdest);
}
