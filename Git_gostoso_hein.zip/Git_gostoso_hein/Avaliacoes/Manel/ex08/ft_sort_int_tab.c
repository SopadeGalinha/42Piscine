/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mapiment <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 13:42:34 by mapiment          #+#    #+#             */
/*   Updated: 2023/03/18 11:29:30 by mapiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab( int *tab, int size)
{
	int	i;
	int	j;
	int	tmp;

	i = 0;
	j = 0;
	tmp = 0;
	while (i < size)
	{
		j = 0;
		while (j < size)
		{
			if (tab[i] < tab[j])
			{
				tmp = tab[i];
				tab[i] = tab[j];
				tab[j] = tmp;
			}
			j++;
		}
		i++;
	}
}
/*
#include <stdio.h>
int main(void){
    int vec[20]={23, 87, 44, 56, 12, 99, 67, 37,
    58, 78, 14, 29, 68, 79, 88, 91, 5, 47, 62, 15};
    int i=0, size=sizeof(vec) / sizeof(int);

    ft_sort_int_tab(vec,size);
    while (i!=size)
    {
        printf("%d ", vec[i]);
        i++;
    }
}
*/
