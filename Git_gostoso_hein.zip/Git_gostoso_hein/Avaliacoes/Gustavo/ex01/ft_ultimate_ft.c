/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glima-da <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 10:16:55 by glima-da          #+#    #+#             */
/*   Updated: 2023/03/16 10:59:57 by glima-da         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
int	main(void)
{
	int	a;

	a = 21;
	nbr = a;
	*nbr1 = &nbr;
	**nbr2 = &nbr1;
	***nbr3 = &nbr2;
	****nbr4 = &nbr3;
	*****nbr5 = &nbr4;
	******nbr6 = &nbr5;
	*******nbr7 = &nbr6;
	********nbr8 = &nbr7;
	printf("%d\n", a);
	ft_ultimate_ft(nbr8);
	printf("%d\n", a);
}*/
