/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inemarti <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/14 19:16:06 by inemarti          #+#    #+#             */
/*   Updated: 2023/03/16 10:33:34 by inemarti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	if (b != 0)
	{
		*div = a / b;
		*mod = a % b;
	}
}

/*#include <stdio.h>

int	main()
{
	int	div, mod, a, b;

	a = 42;
	b = 21;

	ft_div_mod(a, b, &div, &mod);
	printf("\n%d/%d = %d with remainder %d\n\n", a, b, div, mod);
}*/
