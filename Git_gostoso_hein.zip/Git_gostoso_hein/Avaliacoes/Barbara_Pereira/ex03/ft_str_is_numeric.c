/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bapereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 11:55:14 by bapereir          #+#    #+#             */
/*   Updated: 2023/03/24 11:05:21 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	if (str[0] == '\0')
	{
		return (1);
	}
	while (str[i])
	{
		if (str[i] < '0' || str[i] > '9')
		{
			i++;
		}
		else
		{
			return (1);
		}
	}
	return (0);
}

int	main(void)
{
	printf("125:%d\n", ft_str_is_numeric("125"));
	printf("abc:%d\n", ft_str_is_numeric("abc"));
	printf(":%d\n", ft_str_is_numeric(""));
}
