/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joamonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/22 09:28:59 by joamonte          #+#    #+#             */
/*   Updated: 2023/03/22 11:33:31 by joamonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_sqrt(int nb)
{
	long	sqrt;
	long	n;

	n = nb;
	if (n <= 0)
		return (0);
	if (n == 1)
		return (1);
	if (n > 1)
	{
		sqrt = 2;
		while (sqrt * sqrt <= n)
		{
			if (sqrt * sqrt == n)
				return (sqrt);
			sqrt++;
		}
	}
	return (0);
}
/*
int	main(void)
{
	printf("%d", ft_sqrt(121));
}
*/
