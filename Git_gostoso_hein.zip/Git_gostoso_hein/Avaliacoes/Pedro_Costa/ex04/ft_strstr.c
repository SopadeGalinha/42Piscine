/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pedmonte <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 17:29:36 by pedmonte          #+#    #+#             */
/*   Updated: 2023/03/22 13:53:10 by rboia-pe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	if (to_find[0] == '\0')
	{
		return (str);
	}
	while (str[i] != '\0')
	{
		j = 0;
		while (str[i + j] != '\0' && str[i + j] == to_find[j])
		{
			j++;
		}
		if (to_find[j] == '\0')
			return (str + i);
		i++;
	}
	return (0);
}

int main()
{
    char	s1[] = "Escola42";
    char	s2[] = "l";
    char	*p;
    char        *p1;

    p1 = strstr(s1, s2);
    p = ft_strstr(s1, s2);
    printf("ft_strstr: %s", p);
    printf("\nstrstr: %s", p1);


    return 0;
}
