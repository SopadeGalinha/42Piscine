/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dfreitas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/27 11:03:28 by dfreitas          #+#    #+#             */
/*   Updated: 2023/03/27 13:07:26 by dfreitas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_iterative_factorial(int nb)
{
	int	r;

	r = nb;
	if (nb < 0)
	{
		return (0);
	}
	if (nb == 0)
	{
		nb = 1;
	}
	if (nb > 0)
	{
		nb = 1;
		while (r != 0)
		{
			nb = r * nb;
			r--;
		}
	}
	return (nb);
}
/*int main()
{
	printf("%d\n",ft_iterative_factorial(1));
}*/
