/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mapiment <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/16 10:10:19 by mapiment          #+#    #+#             */
/*   Updated: 2023/03/17 09:18:19 by mapiment         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	tmp1;
	int	tmp2;

	tmp1 = *a / *b;
	tmp2 = *a % *b;
	*a = tmp1;
	*b = tmp2;
}
/*
#include <stdio.h>
int main(void){
    int a=42,b=24;
    ft_ultimate_div_mod(&a,&b);
    printf("%d\n",a);
    printf("%d\n",b);
}
*/
