/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tlourenc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/20 11:49:08 by tlourenc          #+#    #+#             */
/*   Updated: 2023/03/20 12:45:23 by tlourenc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int	ft_str_is_printable(char *str)
{
	if (!*str)
	{
		return (1);
	}
	while (*str)
	{
		if (*str >= 32 && *str <= 126)
		{
			str++;
		}
		else
		{
			return (0);
		}
	}
	return (1);
}
/*
int main (void)
{
	char str1[] = "SLKDFHWKDHJWLK";
	char str2[] = "€";
	char str3[] = "Hello World";
	char str4[] = "";

	printf("%d\n%d\n%d\n%d\n", ft_str_is_printable(str1), 
		ft_str_is_printable(str2), ft_str_is_printable(str3), 
		ft_str_is_printable(str4));
}*/
